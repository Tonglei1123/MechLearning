from fastapi import FastAPI, Response
from fastapi.responses import FileResponse
import pandas as pd
import matplotlib.pyplot as plt
import os
import uuid

app = FastAPI()

# 全局加载一次数据
DF = pd.read_csv('某招聘网站数据.csv')

# 确保存放图片的目录存在
CHART_DIR = 'charts'
os.makedirs(CHART_DIR, exist_ok=True)

# ---------- 1. 薪资统计 ----------
@app.get('/analyze/salary_by_district')
def salary_by_district():
    stat = (
        DF.groupby('district')['salary']
          .agg(['mean', 'max', 'min'])
          .reset_index()
          .round(0)
          .astype(int)
          .to_dict(orient='records')
    )
    return {'data': stat}

# ---------- 2. 公司数量 + 图片 ----------
@app.get('/analyze/company_count_chart')
def company_count_chart():
    # 统计
    region_company_count = (
        DF.groupby('district')['companyId']
          .nunique()
          .reset_index()
          .sort_values('companyId', ascending=False)
    )
    data = region_company_count.to_dict(orient='records')

    # 画图
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
    plt.figure(figsize=(10, 6))
    plt.bar(region_company_count['district'],
            region_company_count['companyId'],
            color='skyblue', edgecolor='black')
    for i, v in enumerate(region_company_count['companyId']):
        plt.text(i, v + 0.1, str(v), ha='center', va='bottom')
    plt.title('各地区公司数量')
    plt.xlabel('地区')
    plt.ylabel('公司数量')
    plt.xticks(rotation=45)
    plt.tight_layout()

    # 保存图片
    file_name = f'{uuid.uuid4().hex}.png'
    file_path = os.path.join(CHART_DIR, file_name)
    plt.savefig(file_path, dpi=150)
    plt.close()

    return {
        'data': data,
        'chart_url': f'/charts/{file_name}'
    }

# 提供静态文件访问
@app.get('/charts/{file_name}')
def get_chart(file_name: str):
    return FileResponse(os.path.join(CHART_DIR, file_name))

# ---------- 启动 ----------
if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host='0.0.0.0', port=8000)